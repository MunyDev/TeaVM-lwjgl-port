package org.teavm.webgl2;

import org.teavm.jso.JSObject;

public interface WebGLQuery extends JSObject {

}
