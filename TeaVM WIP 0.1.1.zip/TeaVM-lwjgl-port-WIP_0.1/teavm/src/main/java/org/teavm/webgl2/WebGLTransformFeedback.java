package org.teavm.webgl2;

import org.teavm.jso.JSObject;

public interface WebGLTransformFeedback extends JSObject {

}
