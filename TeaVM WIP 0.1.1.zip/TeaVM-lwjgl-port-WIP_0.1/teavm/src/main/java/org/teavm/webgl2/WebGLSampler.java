package org.teavm.webgl2;

import org.teavm.jso.JSObject;

public interface WebGLSampler extends JSObject {

}
