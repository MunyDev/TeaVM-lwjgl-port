package org.lwjgl.opengl;

public class GLBufferStates {
	public float[] colorBuffer = new float[4096];
	public float[] vertBuffer = new float[4096];
	public float[] normalBuffer = new float[4096];
	public float[] texCoordBuffer = new float[4096];
	
}
